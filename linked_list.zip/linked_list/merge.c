#include <stdio.h>

struct node
{
    int data;
    struct node *next;
};

struct node *head1 = NULL , *tail1 = NULL, *head2 = NULL, *tail2 = NULL;

int main()
{
    struct node s  
    head1->data = 10;
}